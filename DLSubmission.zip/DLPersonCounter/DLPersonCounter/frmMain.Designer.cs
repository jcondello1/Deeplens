﻿namespace DLPersonCounter
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.lvOutput = new System.Windows.Forms.ListView();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.lblOutput1 = new System.Windows.Forms.Label();
			this.btnStart = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lvOutput
			// 
			this.lvOutput.Location = new System.Drawing.Point(941, 28);
			this.lvOutput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.lvOutput.Name = "lvOutput";
			this.lvOutput.Size = new System.Drawing.Size(15, 11);
			this.lvOutput.TabIndex = 6;
			this.lvOutput.UseCompatibleStateImageBehavior = false;
			this.lvOutput.Visible = false;
			// 
			// lblOutput1
			// 
			this.lblOutput1.AutoSize = true;
			this.lblOutput1.Font = new System.Drawing.Font("Microsoft Sans Serif", 55F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblOutput1.Location = new System.Drawing.Point(246, 181);
			this.lblOutput1.Name = "lblOutput1";
			this.lblOutput1.Size = new System.Drawing.Size(152, 166);
			this.lblOutput1.TabIndex = 7;
			this.lblOutput1.Text = "0";
			// 
			// btnStart
			// 
			this.btnStart.Location = new System.Drawing.Point(288, 452);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(131, 62);
			this.btnStart.TabIndex = 8;
			this.btnStart.Text = "Start";
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(465, 452);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(122, 62);
			this.btnCancel.TabIndex = 9;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(48, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(519, 76);
			this.label1.TabIndex = 10;
			this.label1.Text = "Customer Count";
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(628, 542);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnStart);
			this.Controls.Add(this.lblOutput1);
			this.Controls.Add(this.lvOutput);
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "frmMain";
			this.Text = "Customer Count";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListView lvOutput;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.Label lblOutput1;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label label1;
	}
}

