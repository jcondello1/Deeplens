﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DLPersonCounter
{
    internal class Utility
    {
        // Get the connection string from App config file
        internal static string GetConnectionString()
        {
            string returnValue = null;

            string conn = ConfigurationManager.AppSettings["connString"];

            //If found, return the connection string.
            if (conn != null)
                returnValue = conn;

            return returnValue;
        }

        // Get the path for where application data is stored
        internal static string GetPathForAppData()
        {
            string returnValue = null;

            string path = Application.LocalUserAppDataPath;

            //If found, return the connection string.
            if (path != null)
                returnValue = path;

            return returnValue;
        }

        // Get the connection string from App config file
        internal static string GetTechSupportEmail()
        {
            return ConfigurationManager.AppSettings["TechSupportEmail"];
		}

		// Get the SQS URL
		internal static string GetSQSURL()
		{
			return ConfigurationManager.AppSettings["AWSSQSURL"];
		}

		// Get the Environment from App config file
		internal static string GetEnvironment()
        {
            return ConfigurationManager.AppSettings["Environment"];
        }
    }
}