﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Amazon.SQS;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Threading;

namespace DLPersonCounter
{
    public partial class frmMain : Form
    {
		string sStatus = "0";
		DataAccess da = new DataAccess();

		public frmMain(string[] args)
        {
			// Method required for Designer support
			InitializeComponent();

			InitializeBackgroundWorker();

			// Initial setup for any of the forms controls
			SetupForm();

            // Exit Application
            if (args.Length != 0)
            {
                if (args[0] == "s")
                {
                    Environment.Exit(1);
                }
            }
        }

		// Set up the BackgroundWorker object by 
		// attaching event handlers. 
		private void InitializeBackgroundWorker()
		{
			backgroundWorker1.WorkerReportsProgress = true;
			backgroundWorker1.WorkerSupportsCancellation = true;

			backgroundWorker1.DoWork +=
				new DoWorkEventHandler(backgroundWorker1_DoWork);
			backgroundWorker1.RunWorkerCompleted +=
				new RunWorkerCompletedEventHandler(
			backgroundWorker1_RunWorkerCompleted);
			backgroundWorker1.ProgressChanged +=
				new ProgressChangedEventHandler(
			backgroundWorker1_ProgressChanged);
		}

		// Execute and setup for the UI
		private bool SetupForm()
        {
            // Setup the form's grids
            SetupGrids();

            return true;
        }

        private bool SetupGrids()
        {
            // Add columns to log listview
            lvOutput.View = View.Details;
            lvOutput.Columns.Add("Time");
            lvOutput.Columns[0].Width = 85;
            lvOutput.Columns.Add("Method");
            lvOutput.Columns[1].Width = 175;
            lvOutput.Columns.Add("Message");
            lvOutput.Columns[2].Width = 2000;

            return true;
        }
		
		private void btnStart_Click(object sender, EventArgs e)
		{
			if (backgroundWorker1.IsBusy != true)
			{
				// Start the asynchronous operation.
				backgroundWorker1.RunWorkerAsync();
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			if (backgroundWorker1.WorkerSupportsCancellation == true)
			{
				// Cancel the asynchronous operation.
				backgroundWorker1.CancelAsync();
			}
		}

		// Get data from SQS
		// TODO: This needs to be tuned and optimzed
		private List<Amazon.SQS.Model.Message> GetDataFromSQS(object sender, DoWorkEventArgs e)
        {
			BackgroundWorker worker = sender as BackgroundWorker;

			int msgCount = 0;
            // We need to try multiple times due to known distributed model on SQS.
            int attempOnZero = 0;

            Amazon.SQS.Model.ReceiveMessageResponse response = null;

            List<Amazon.SQS.Model.Message> sesDataList = new List<Amazon.SQS.Model.Message>();

            AmazonSQSClient client = new AmazonSQSClient();
            Amazon.SQS.Model.ReceiveMessageRequest request = new Amazon.SQS.Model.ReceiveMessageRequest
            {
                AttributeNames = new List<string>() { "All" },
                MaxNumberOfMessages = 10,
                QueueUrl = Utility.GetSQSURL(),
                VisibilityTimeout = (int)TimeSpan.FromMinutes(15).TotalSeconds,
                WaitTimeSeconds = (int)TimeSpan.FromSeconds(10).TotalSeconds
            };

            do
            {
                response = client.ReceiveMessage(request);
                msgCount = response.Messages.Count;

                if(msgCount > 0)
                {
                    foreach (var message in response.Messages)
                    {
						if (worker.CancellationPending == true)
						{
							e.Cancel = true;
							break;
						}
						else
						{
							// Perform a time consuming operation and report progress.
							LogOutput("GetDataFromSQS", "For message ID '" + message.MessageId + "':");
							LogOutput("GetDataFromSQS", "  Body: " + message.Body);
							LogOutput("GetDataFromSQS", "  Receipt handle: " + message.ReceiptHandle);
							LogOutput("GetDataFromSQS", "  MD5 of body: " + message.MD5OfBody);
							LogOutput("GetDataFromSQS", "  MD5 of message attributes: " +
							  message.MD5OfMessageAttributes);
							LogOutput("GetDataFromSQS", "  Attributes:");

							//foreach (var attr in message.Attributes)
							//{
							//    LogOutput("GetDataFromSQS", "    " + attr.Key + ": " + attr.Value);
							//}

							// Add to list for future processing
							sesDataList.Add(message);

							// Delete message from queue
							Amazon.SQS.Model.DeleteMessageRequest req = new Amazon.SQS.Model.DeleteMessageRequest();
							req.QueueUrl = Utility.GetSQSURL();
							req.ReceiptHandle = message.ReceiptHandle;
							client.DeleteMessage(req);

							// Only handle data that is in the correct format
							if (message.Body.Contains(":"))
							{
								Char delimiter = ',';
								string[] aHeadCount = message.Body.Replace("{", "").Replace("}", "").Replace("\"", "").Replace("/", "").Split(delimiter);
								int iTest = aHeadCount.Length;

								if (iTest > 1)
								{
									int temp = iTest;
								}

								//Char delimiter = ':';
								//string[] aData = message.Body.Replace("{", "").Replace("}", "").Replace("/", "").Replace("\"", "").Split(delimiter);
								
								sStatus = iTest.ToString();
							}
							else
							{
								sStatus = "0";
							}
							
							da.WriteToRDSLog(Convert.ToInt32(sStatus));

							// Call this to trigger event; 1 is irrelevant
							worker.ReportProgress(1);

							LogOutput("GetDataFromSQS", " Message Deleted: " + message.MessageId);
						}
                    }
                }else
                {
                    attempOnZero++;

					sStatus = "0";

					// Call this to trigger event; 1 is irrelevant
					worker.ReportProgress(1);
				}
            }while (attempOnZero < 200000); // Need at least two zero count attempts
			
			// Reset to zero in the end
			sStatus = "0";

			// Call this to trigger event; 1 is irrelevant
			worker.ReportProgress(1);

			if (sesDataList.Count > 0)
            {
                LogOutput("GetDataFromSQS", "Total count: " + sesDataList.Count.ToString());
            }
            else
            {
                LogOutput("GetDataFromSQS", "No data returned from source.");
            }

            return sesDataList;
        }

		private bool LogOutput(string sMethod, string sMessage)
        {
            ListViewItem listitem = new ListViewItem(new[] { DateTime.Now.ToString("HH:mm:ss:ff"), sMethod, sMessage });
            //lvOutput.Items.Add(listitem);

            return true;
        }

        // Update records with success info
        private bool NotifyTechOfFailures()
        {
            // For any and all failures send an email to Tech

            string sFrom = "jcondello1@yahoo.com"; // guardian.FromEmailAddr;   // Replace with your "From" address. This address must be verified.
            string sTo = Utility.GetTechSupportEmail();
            string sSubject = "DLPersonCounter Batch Log";
            string sBody = "";

            // lvOutput
            foreach (ListViewItem item in lvOutput.Items)
            {
                for (int i = 0; i < item.SubItems.Count; i++)
                {
                    sBody += item.SubItems[i].Text + "&nbsp;&nbsp;&nbsp;&nbsp;";
                }

                sBody += "<br/>";
            }

            EmailManager.SendEmail.Send(sFrom, sTo, sSubject, sBody);

            LogOutput("NotifyTechOfFailures", "Email sent to Tech Support");

            return true;
        }

		// This event handler is where the time-consuming work is done.
		private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
		{
			//BackgroundWorker worker = sender as BackgroundWorker;
			
			// Get data from SQS
			List<Amazon.SQS.Model.Message> listEmailIssues = GetDataFromSQS(sender, e);

			//for (int i = 1; i <= 10; i++)
			//{
			//	if (worker.CancellationPending == true)
			//	{
			//		e.Cancel = true;
			//		break;
			//	}
			//	else
			//	{
			//		// Perform a time consuming operation and report progress.
			//		System.Threading.Thread.Sleep(500);

			//		sStatus = (i * 10).ToString();
			//	    worker.ReportProgress(i * 10);
			//	}
			//}
		}

		// This event handler updates the progress.
		private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
		{
			lblOutput1.Text = sStatus; //(e.ProgressPercentage.ToString() + "%");
		}

		// This event handler deals with the results of the background operation.
		private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (e.Cancelled == true)
			{
				lblOutput1.Text = "Canceled!";
			}
			else if (e.Error != null)
			{
				lblOutput1.Text = "Error: " + e.Error.Message;
			}
			else
			{
				lblOutput1.Text = "Done!";
			}
		}
	}
}
