﻿using System;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Data;
using System.Data.SqlClient;

namespace DLPersonCounter
{
    class DataAccess
    {
        public string LastOutput = "";
        SqlConnection conn = new SqlConnection(Utility.GetConnectionString());

		// Write to log
		public bool WriteToRDSLog(int PersonCount)
		{
			SqlCommand cmdObject = new SqlCommand("WriteToLog", conn);
			cmdObject.CommandType = CommandType.StoredProcedure;

			try
			{
				cmdObject.Parameters.Add("@LogData", SqlDbType.Int).Value = PersonCount;

				conn.Open();
				cmdObject.ExecuteNonQuery();

				LastOutput = "Inserted Log Record";
			}
			catch (Exception ex)
			{
				LastOutput = "Failed to Insert Log Record. Error: " + ex.Message;
			}
			finally
			{
				conn.Close();
			}

			return true;
		}
    }
}
