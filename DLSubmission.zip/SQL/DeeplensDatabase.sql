USE [master]
GO
/****** Object:  Database [deeplens]    Script Date: 2/10/2018 6:35:40 PM ******/
CREATE DATABASE [deeplens]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'deeplens', FILENAME = N'D:\RDSDBDATA\DATA\deeplens.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'deeplens_log', FILENAME = N'D:\RDSDBDATA\DATA\deeplens_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [deeplens] SET COMPATIBILITY_LEVEL = 130
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [deeplens].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [deeplens] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [deeplens] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [deeplens] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [deeplens] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [deeplens] SET ARITHABORT OFF 
GO
ALTER DATABASE [deeplens] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [deeplens] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [deeplens] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [deeplens] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [deeplens] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [deeplens] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [deeplens] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [deeplens] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [deeplens] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [deeplens] SET  DISABLE_BROKER 
GO
ALTER DATABASE [deeplens] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [deeplens] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [deeplens] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [deeplens] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [deeplens] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [deeplens] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [deeplens] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [deeplens] SET RECOVERY FULL 
GO
ALTER DATABASE [deeplens] SET  MULTI_USER 
GO
ALTER DATABASE [deeplens] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [deeplens] SET DB_CHAINING OFF 
GO
ALTER DATABASE [deeplens] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [deeplens] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
ALTER DATABASE [deeplens] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [deeplens] SET QUERY_STORE = OFF
GO
USE [deeplens]
GO
ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 0;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET MAXDOP = PRIMARY;
GO
ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET LEGACY_CARDINALITY_ESTIMATION = PRIMARY;
GO
ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = ON;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET PARAMETER_SNIFFING = PRIMARY;
GO
ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = OFF;
GO
ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET QUERY_OPTIMIZER_HOTFIXES = PRIMARY;
GO
USE [deeplens]
GO
/****** Object:  User [bizfun]    Script Date: 2/10/2018 6:35:41 PM ******/
CREATE USER [bizfun] FOR LOGIN [bizfun] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [bizfun]
GO
/****** Object:  Table [dbo].[Log]    Script Date: 2/10/2018 6:35:41 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Log](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[Data] [int] NOT NULL,
	[InsertDttm] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_Log] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[Log] ADD  CONSTRAINT [DF_Log_InsertDttm]  DEFAULT (getdate()) FOR [InsertDttm]
GO
/****** Object:  StoredProcedure [dbo].[GetLogData]    Script Date: 2/10/2018 6:35:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Jason Condello>
-- Create date: <2018-02-01>
-- Description:	<Get Person Count from Log>
-- =============================================
CREATE PROCEDURE [dbo].[GetLogData]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    --Get log data
	SELECT AVG(Data) AS Average, Format(dateadd(HOUR, -8, InsertDttm), 'hh tt') AS "Hour"
	FROM Log
	GROUP BY Format(dateadd(HOUR, -8, InsertDttm), 'hh tt'), datepart(HOUR, dateadd(HOUR, -8, InsertDttm))
	ORDER BY datepart(HOUR, dateadd(HOUR, -8, InsertDttm))

END

GO
/****** Object:  StoredProcedure [dbo].[WriteToLog]    Script Date: 2/10/2018 6:35:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Jason Condello>
-- Create date: <2018-02-01>
-- Description:	<Write Person Count to Log>
-- =============================================
CREATE PROCEDURE [dbo].[WriteToLog]
	@LogData int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO Log (Data) VALUES (@LogData)
END

GO
USE [master]
GO
ALTER DATABASE [deeplens] SET  READ_WRITE 
GO
