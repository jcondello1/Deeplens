﻿using System;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Data;
using System.Data.SqlClient;

namespace DLReport
{
    public class DataAccess
    {
        public string LastOutput = "";
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connString"].ConnectionString);

		// Write to log
		public bool WriteToRDSLog(int PersonCount)
		{
			// Update Batch Detail with Send Date
			SqlCommand cmdObject = new SqlCommand("WriteToLog", conn);
			cmdObject.CommandType = CommandType.StoredProcedure;

			try
			{
				cmdObject.Parameters.Add("@LogData", SqlDbType.Int).Value = PersonCount;

				conn.Open();
				cmdObject.ExecuteNonQuery();

				LastOutput = "Inserted Log Record";
			}
			catch (Exception ex)
			{
				LastOutput = "Failed to Insert Log Record. Error: " + ex.Message;
			}
			finally
			{
				conn.Close();
			}

			return true;
		}

        // Get report data for chart
        public DataTable GetReportData()
        {
            SqlCommand cmdObject = new SqlCommand("GetLogData", conn);
            cmdObject.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();

            //try
            //{
                conn.Open();

                SqlDataReader myReader = cmdObject.ExecuteReader();
                dt.Load(myReader);

                LastOutput = "Retrieved log data from RDS";
            //}
            //catch (Exception ex)
            //{
            //    LastOutput = "Failed to retrieve log data from RDS. Error: " + ex.Message;
            //}
            //finally
            //{
            //    conn.Close();
            //}
            
            return dt;
        }
    }
}
