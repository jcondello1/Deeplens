﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
	{
		DLReport.DataAccess da = new DLReport.DataAccess();
		DataTable dt = new DataTable();

		dt = da.GetReportData();

		string sChartData = "['Hour of Day', 'Count'],";
		foreach (DataRow row in dt.Rows)
		{
			sChartData += "['" + row["Hour"].ToString() + "', " + row["Average"].ToString() + "],";
		}

		js_target.Text = sChartData.TrimEnd(',');
	}
}